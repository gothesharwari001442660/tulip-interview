import React, { Component } from 'react';

class App extends Component {

  constructor(props) {
    super(props);
    this.state = {
      value: '',
      unique: false,
      error: ''
    };
    this.onKeyUp = this.onKeyUp.bind(this);
  }

  onKeyUp(event) {
    var takenNew;
    console.log(event.target.value.length);
    
    if(event.target.value.length === 0) {
      this.setState({error: ''});
    }
    if(event.target.value.length != 0 && event.target.value.length < 4) {
      this.setState({error: 'Username must be atleast 4 characters long'});
    }
    if(event.target.value.length >= 4) {
      this.setState({error: ''});
      const fetchPromise = fetch('https://hxj1tck8l1.execute-api.us-east-1.amazonaws.com/default/users/taken?username='+event.target.value)
      fetchPromise.then(res => {
        return res.json()
      }).then(data => {
        console.log(data.taken);
        this.setState({unique: data.taken});
        if(this.state.unique) {
          alert("Username is Unique");
        }
      })
    }
    
  }

  render() {
    return (
      <form>
        <label>
          Name:
        <input type="text" onKeyUp={this.onKeyUp} />
        </label>
        <label>{this.state.error}</label>
      </form>
    );
  }
}

export default App;
